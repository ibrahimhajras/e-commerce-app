package com.example.e_commerce01

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
