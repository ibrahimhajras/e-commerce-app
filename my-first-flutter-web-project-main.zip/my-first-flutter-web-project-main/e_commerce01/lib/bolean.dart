class costbol {
  static bool Home = true;
  static bool Contact = false;
  static bool Cart = false;
  static bool details = false;

  static double totalPriceCart=0;
}