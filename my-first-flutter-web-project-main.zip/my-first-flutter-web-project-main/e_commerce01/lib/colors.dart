import 'dart:ui';

import 'package:flutter/material.dart';

class colours{
  static Color bk=Colors.black;
  static Color blu=Color(0xff14213d);
  static Color yl=Color(0xfffca311);
  static Color gr=Color(0xffe5e5e5);
  static Color wh=Color(0xffffffff);
}