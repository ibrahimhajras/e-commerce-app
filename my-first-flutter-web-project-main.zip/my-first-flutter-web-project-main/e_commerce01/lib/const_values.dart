class ConsValues {
  static String BASEURL = "http://localhost:81/apis";
  static String ID = "Id";
  static String NAME = "Name";
  static String EMAIL = "Email";
  static String PHONE = "Phone";
  static String USER_TYPE = "IdUserType";
  static bool isLoggedin =false;
}
