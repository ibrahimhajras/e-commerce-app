package com.example.flutter_irbed_10_am

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
