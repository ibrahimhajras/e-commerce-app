class ConsValues {
  static String BASEURL = "https://alshalbiapps.com/flutter_10_am_irbed/";
  static String ID = "Id";
  static String NAME = "Name";
  static String EMAIL = "Email";
  static String PHONE = "Phone";
  static String USER_TYPE = "UserType";
}
